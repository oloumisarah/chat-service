Program Author: Sarah
Course Code: COMP2406B
Assignment number : 3

1) open cmd prompt 
	>run server by typing in node server.js
	
2) Once the server is running, open chrome or firefox and type in 
	>http://localhost:2406/index.html

3) The program will prompt for a username. You should type in preferred username.

4) Open however many more windows you want and bring more users in the chat and start chatting!

5) In order to block a user, hold shift and double click on their name. They will not be able to send you anymore messages

6) In order to send a specific user, double click on their name.