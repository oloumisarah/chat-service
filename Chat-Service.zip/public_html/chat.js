/*
Student number: Sarah Oloumi
Course Code: 2406B
Used tutorial7 code for this. 

*/
$(document).ready(function() {
	
	var userName = prompt("Enter your username:") || "User";

	var socket = io(); //connect to the server that sent this page
	socket.on('connect', function() {
		socket.emit("intro", userName);
	});

	$('#inputText').keypress(function(ev) {
		if (ev.which === 13) {
			//send message
			socket.emit("message", $(this).val());
			ev.preventDefault(); //if any
			$("#chat").append((new Date()).toLocaleTimeString() + ", " + userName + ": " + $(this).val() + "\n")
			$(this).val(""); //empty the input
		}
	});

	socket.on("message", function(data) {
		console.log(data);
		$("#chat").append(data + "\n");
		$('#chat')[0].scrollTop = $('#chat')[0].scrollHeight; //scroll to the bottom
	});
	
	socket.on("privateMessage", function(data) {
		console.log("pm data ", data);
		console.log("pm data.message ", data.message);
		//displays who sent +their message
		var userPm = prompt(data.sender + " sent " + data.message + "\nreply:");
		if (userPm != null && userPm !== "") {
			// reply to originial sender
			socket.emit("privateMessage", {'username': data.sender, 'userPm': userPm}); // send over username + private message to the server
		}
	});
	
	//fills the list of users
	socket.on("userListDiv", function(data) {
		var myList = $("#list");
		
		myList.html("");
		//console.log("Here");
		// list.html('<ul id=userListDiv </ul>');
		console.log("userListDiv ", data);
		
		//Loop over the data sent with the event (which should be a JSON object)
		//and append a new list item for every user in the data.users array.
		for (var j = 0; j < data.length; j++) {
			var listItems = $("<li>" + data[j] + "</li>");
			myList.append(listItems);
			console.log(listItems);
			// this is the person thats being clicked
			// socket is the person doing the clicking
			listItems.dblclick(function(event){click(event, $(this), socket)});
		}

		// $('#userListDiv').append($userObj);
	});

});

function click (event, personClicked, socket){
	// var userchoice = event.data;

	if (event.shiftKey) { // if its dbl click +shift key then block users
		if (socket.username !== personClicked.html()) {
			socket.emit('blockUser', {'username': personClicked.html()}); // send data to server to block user
			// this will add the block class if the person doesnt have it and then remove it if they do
			personClicked.toggleClass("myblock", !personClicked.hasClass("myblock"));
		}
	}


	else {
		var userPm;
		if (socket.username !== personClicked.html()) {
			userPm = prompt("private message...");
		}
		if (userPm != null && userPm !== "") {
			socket.emit("privateMessage", {'username': personClicked.html(), 'userPm': userPm}); // send over username + private message to the server
		}
	}
}
