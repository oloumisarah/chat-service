/*
Student number: Sarah Oloumi
Course Code: 2406B
Used tutorial7 code for this. 

*/

/*SocketIO based chat room. Extended to not echo messages
to the client that sent them.*/

var http = require('http').createServer(handler);
var io = require('socket.io')(http); // create a new socket.io instance attached to the http server
var fs = require('fs');
var url = require('url');
const ROOT = "./public_html";
var clients = []; //stores the clients
// import mimetyps then use mime types to check if the file is css and then if it is then load it
http.listen(2406);

console.log("Chat server is now listening on port 2406");


function handler(req, res) {
    var urlObj = url.parse(req.url, true);

    var data = "";
    var filename = ROOT + urlObj.pathname;

    if (fs.existsSync(filename)) {
        var stats = fs.statSync(filename);

        if (stats.isDirectory()) {
            filename += "/index.html";
        }

        console.log("getting the file: " + filename);
        data = fs.readFileSync

        fs.readFile(filename, function(err, data) {
            if (err) {
                res.writeHead(500);
                return res.end("Error loading chatRoom.html");
            } else {
                res.writeHead(200);
                res.end(data);
            }
        });
    };

    //locally defined helper function
    //serves 404 files
    function serve404() {
        fs.readFile(ROOT + "./404.html", "utf8", function(err, data) { //async
            if (err) respond(500, err.message);
            else respond(404, data);
        });
    }

    //locally defined helper function
    //responds in error, and outputs to the console
    function respondErr(err) {
        console.log("Handling error: ", err);
        if (err.code === "ENOENT") {
            serve404();
        } else {
            respond(500, err.message);
        }
    }

    //locally defined helper function
    //sends off the response message
    function respond(code, data) {
        // content header
        res.writeHead(code, {
            'content-type': mime.lookup(filename) || 'text/html'
        });
        // write message and signal communication is complete
        res.end(data);
    }
}


    //whenever someone connects this gets executed
io.on("connection", function(socket) {
	
	console.log("Got a connection");
	
	// var username;
	socket.on("intro", function(data) {
		clients.push(socket); //
		socket.username = data;
		socket.broadcast.emit("message", timestamp() + ": " + socket.username + " has entered the chatroom.");
		socket.emit("message", "Welcome, " + socket.username + ".");
		io.emit("userListDiv", getUserList());
	});

	socket.on("message", function(data) {
		console.log("got message: " + data);
		socket.broadcast.emit("message", timestamp() + ", " + socket.username + ": " + data);

	});

	//whenever someone disconnects, this piece of code is executed
	socket.on("disconnect", function() {
		console.log(socket.username + " disconnected");
		io.emit("message", timestamp() + ": " + socket.username + "disconnected.");
		clients = clients.filter(function(ele) { //finds the client and disconnects them
			return ele !== socket;
		});
		console.log(socket.username + " disconnected");
		io.emit("message", timestamp() + ": " + socket.username + " disconnected.");
		for(var i=0; i<clients.length; i++){
			if(clients[i]=== socket){
				clients.splice(i,1);
			}
		}
		io.emit("userListDiv", getUserList());
	});

	//get user private message
	socket.on("privateMessage", function(data) {
		console.log("Got private message: " + data.userPm);
		console.log("Username of current socket: " + data.username);
		//iterate through the users
		for (var i = 0; i < clients.length; i++) {
			// if the user sending the message is in the list and the user doesnt have a blocked user list or the reciever isnt on the list
			if (clients[i].username == data.username){ 
				if(clients[i].blockedUserList == null || clients[i].blockedUserList.indexOf(socket.username) ===-1) {
					clients[i].emit("privateMessage", {"sender": socket.username, "message": data.userPm});
				}
			}
		}
	});
	
	socket.on("blockUser", function(data) {
		/*appends the provided username to a list of blocked user for requesting client
		  if user is already blocked, then user should handle the event by removing the user from blocked list.*/
		console.log("Got object" + data);
		//var data = data);
		console.log("The username passed: " + data.username);

		if (socket.blockedUserList == null) { //if they dont have a blocked user list
			socket.blockedUserList = [];
			socket.blockedUserList.push(data.username);
			console.log("User " + data.username + " blocked.");
		}else{ // otherwise they do have a blockedUserList
			if(socket.blockedUserList.indexOf !== -1){ // if theyre in blocked user list
				socket.blockedUserList.splice(socket.blockedUserList.indexOf(data.username), 1);
			}
			else{ // if theyre not in the blocked 
				socket.blockedUserList.push(data.username);
			}
		}
	});
});

function timestamp() {
	return new Date().toLocaleTimeString();
}

function getUserList() {
	var ret = [];
	for (var i = 0; i < clients.length; i++) { // uses for loop to see how many sockets u have
		//get username from socket and make a list so you can have user list
		ret.push(clients[i].username);
	}
	return ret;
}

function findUserList(selectedUser) {
	for (var i = 0; i < clients.length; i++) {
		if (clients[i].username == selectedUser)
			return clients[i];
	}
	return 0;
}
